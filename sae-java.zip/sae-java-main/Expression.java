public abstract class Expression {
    public abstract double valeur();
} // fin classe Expression 